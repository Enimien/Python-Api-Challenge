# OpenWeatherMap API Key
weather_api_key = "f6b4faf5716c469df6dfe5dcaeba58e3"

# Geoapify API Key
geoapify_key = "8d386f5353044c949c5d5289c703e270"
